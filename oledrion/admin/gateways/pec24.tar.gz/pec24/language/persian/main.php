<?php
/**
 * ****************************************************************************
 * oledrion BPLC - MODULE FOR XOOPS
 * Copyright (c) Hervé Thouzard of Instant Zero (http://www.instant-zero.com)
 *
 * You may not change or alter any portion of this comment or credits
 * of supporting developers from this source code or any supporting source code
 * which is considered copyrighted (c) material of the original comment or credit authors.
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * @copyright       Hervé Thouzard of Instant Zero (http://www.instant-zero.com)
 * @license         http://www.fsf.org/copyleft/gpl.html GNU public license
 * @package         oledrion BPLC
 * @author 			Hervé Thouzard of Instant Zero (http://www.instant-zero.com)
 *
 * Version : $Id:
 * ****************************************************************************
 */
define("_OLEDRION_SAMAN_PARAMETERS","پارامترها");
define('_OLEDRION_SAMAN_MID', "کد فروشنده");
define('_OLEDRION_SAMAN_MIDDSC', "ترکيب Terminal ID و Acceptor ID که توسط بانک به فروشنده اختصاص مي‌يابد.");
?>
<?php
if (!defined('XOOPS_ROOT_PATH')) {
    die("XOOPS root path not defined");
}
//require_once('nusoap.php');

class oledrion_pec24 extends oledrion_gateway
{
    function __construct()
    {
        parent::__construct();
    }

    function setGatewayInformation()
    {
        $gateway = array();
        $gateway['name'] = 'Parsian';
        $gateway['foldername'] = 'pec24';
        $gateway['version'] = '1.0';
        $gateway['description'] = "سيستم پرداخت الکترونيک بانک پارسیان";
        $gateway['author'] = "Hossein Azizabadi";
        $gateway['credits'] = "جسین عزیزآبادی";
        $gateway['releaseDate'] = 20121020;
        $this->gatewayInformation = $gateway;
    }

    function getParametersForm($postUrl)
    {
        $sform = new XoopsThemeForm(_OLEDRION_PARSIAN_PARAMETERS . ' - ' . $this->gatewayInformation['name'], 'frmParsian', $postUrl);
        $sform->addElement(new XoopsFormHidden('gateway', $this->gatewayInformation['foldername']));
        $pin = new XoopsFormText(_OLEDRION_PARSIAN_MID, 'parsian_mid', 50, 255, $this->handlers->h_oledrion_gateways_options->getGatewayOptionValue($this->gatewayInformation['foldername'], 'parsian_mid'));
        $pin->setDescription(_OLEDRION_PARSIAN_MIDDSC);
        $sform->addElement($pin, true);
        $button_tray = new XoopsFormElementTray('', '');
        $submit_btn = new XoopsFormButton('', 'post', _AM_OLEDRION_GATEWAYS_UPDATE, 'submit');
        $button_tray->addElement($submit_btn);
        $sform->addElement($button_tray);
        return $sform;
    }

    function saveParametersForm($data)
    {
        if (xoops_trim($this->languageFilename) != '' && file_exists($this->languageFilename)) {
            require $this->languageFilename;
        }
        $gatewayName = $this->gatewayInformation['foldername'];
        $this->handlers->h_oledrion_gateways_options->deleteGatewayOptions($gatewayName);
        if (!$this->handlers->h_oledrion_gateways_options->setGatewayOptionValue($gatewayName, 'parsian_mid', $data['parsian_mid'])) return false;
        return true;
    }

    private function formatAmount($amount)
    {
        return number_format($amount, 2, '.', '');
    }

    function getAuthority($cmd_total, $cmd_id)
    {
        
        $url = $this->getdialogURL();
        if (extension_loaded('soap')) {
            $soapclient = new SoapClient($url);
        } else {
            require_once('nusoap.php');
            $soapclient = new soapclient($url, 'wsdl');
        }

		  $params = array(
				'pin' => $this->getParsianMid(),
				'amount' => intval($this->formatAmount($cmd_total)),
				'orderId' => intval($cmd_id),
				'callbackUrl' => OLEDRION_URL . 'gateway-notify.php',
				'authority' => 0,
				'status' => 1
			);
			
		   $sendParams = array($params) ;
		   $res = $soapclient->call('PinPaymentRequest', $sendParams);
         return $res['authority'];
    }

    function getParsianMid()
    {
        global $xoopsConfig;
        $gatewayName = $this->gatewayInformation['foldername'];
        $parsian_mid = $this->handlers->h_oledrion_gateways_options->getGatewayOptionValue($gatewayName, 'parsian_mid');
        return $parsian_mid;
    }

    function getRedirectURL($cmd_total, $cmd_id)
    {
        $authority = $this->getAuthority($cmd_total, $cmd_id);
        return "https://www.pecco24.com:27635/pecpaymentgateway/?au=" . $authority;
    }

    function getCheckoutFormContent($order)
    {
        $ret = array();
        $ret['pin'] = $this->getParsianMid();
        $ret['amount'] = intval($this->formatAmount($order->getVar('cmd_total')));
        $ret['orderId'] = $order->getVar('cmd_id');
        $ret['callbackUrl'] = OLEDRION_URL . 'gateway-notify.php';
        $ret['authority'] = 0;
        $ret['status'] = 1;
        return $ret;
    }

    function getCountriesList()
    {
        require_once XOOPS_ROOT_PATH . '/class/xoopslists.php';
        return XoopsLists::getCountryList();
    }

    private function getdialogURL()
    {
        return 'https://www.pecco24.com:27635/pecpaymentgateway/eshopservice.asmx?wsdl';
    }

    function gatewayNotify($gatewaysLogPath)
    {
        $slashes = get_magic_quotes_gpc();
        foreach ($_POST as $key => $value) {
            if ($slashes) {
                $log .= "$key=" . stripslashes($value) . "\n";
            } else {
                $log .= "$key=" . $value . "\n";
            }
        }
        if ($slashes) {
            $ref = stripslashes($_REQUEST['au']);
        } else {
            $ref = stripslashes($_REQUEST['au']);
        }

        $url = $this->getdialogURL();
        if (extension_loaded('soap')) {
            $soapclient = new SoapClient($url);
            $res = $soapclient->VerifyTransaction($ref, $this->getParsianMid());
        } else {
            require_once('nusoap.php');
            $soapclient = new soapclient($url, 'wsdl');
            $soapProxy = $soapclient->getProxy();
            if ($err = $soapclient->getError())
                echo $err;
            $res = $soapProxy->VerifyTransaction($ref, $this->getParsianMid());
        }

        if ($res > 0) {
            $log .= "VERIFIED\t";
            $paypalok = true;
            if (strtoupper($_REQUEST['rs']) != 'OK') $paypalok = false;
            if (!$_REQUEST['au']) $paypalok = false;
            //if (!$_POST['RefNum']) $paypalok = false;
            if ($paypalok) {
                $ref = intval($_REQUEST['au']);
                $commande = null;
                $commande = $this->handlers->h_oledrion_commands->get($ref);
                if (is_object($commande)) {
                    if ($res == $commande->getVar('cmd_total')) {
                        $this->handlers->h_oledrion_commands->validateOrder($commande);
                    } else {
                        $this->handlers->h_oledrion_commands->setFraudulentOrder($commande);
                    }
                }
            } else {
                if (isset($_REQUEST['au'])) {
                    $ref = intval($_REQUEST['au']);
                    $commande = null;
                    $commande = $this->handlers->h_oledrion_commands->get($ref);
                    if (is_object($commande)) {
                        $State = $_REQUEST['rs'];
                        switch ($State) {

                        }
                    }
                }
            }
        } else {
            $ref = intval($_REQUEST['au']);
            $commande = null;
            $commande = $this->handlers->h_oledrion_commands->get($ref);
            if (is_object($commande)) {

                switch ($res) {

                }

            }
            $log .= "$res\n";
        }

        // Ecriture dans le fichier log
        $fp = fopen($gatewaysLogPath, 'a');
        if ($fp) {
            fwrite($fp, str_repeat('-', 120) . "\n");
            fwrite($fp, date('d/m/Y H:i:s') . "\n");
            if (isset($_POST['RefNum'])) {
                fwrite($fp, "Transaction : " . $_POST['RefNum'] . "\n");
            }
            fwrite($fp, "Result : " . $log . "\n");
            fclose($fp);
        }

    }
}

?>